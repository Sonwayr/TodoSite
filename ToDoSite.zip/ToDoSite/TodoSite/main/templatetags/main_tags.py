from django import template
from django.db.models import Count
from django.template import RequestContext

from main.models import *

register = template.Library()


@register.inclusion_tag('main/show_menu.html')
def show_menu(request):
    return {'request': request}


@register.inclusion_tag('main/templatetag_task.html')
def show_task(tasks, completed):
    return {'tasks': tasks, 'completed': completed}

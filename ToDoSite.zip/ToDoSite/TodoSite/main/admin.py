from django.contrib import admin
from django.contrib.auth.models import User

from .models import Task, UserTask


class UserTaskInline(admin.StackedInline):
    model = Task


class AdminUser(admin.ModelAdmin):
    list_display = ('id', 'user', 'all_task_count', 'tasks_in_progress', 'completed_tasks')
    list_display_links = ('id', 'user')
    inlines = [UserTaskInline]
    save_on_top = True


admin.site.register(UserTask, AdminUser)
admin.site.site_title = 'Админ-панель SW'
admin.site.site_header = 'Админ-панель SW'

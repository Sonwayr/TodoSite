from django.urls import path

from .views import *

urlpatterns = [
    path('', main_page, name='main'),
    path('register/', RegisterUser.as_view(), name='register'),
    path('tasks/', ShowTasks.as_view(), name='show_tasks'),
    path('logout/', logout_user, name='logout'),
    path('login/', LoginUser.as_view(), name='login'),
    path('add_page/', CreateTask.as_view(), name='add_task'),
    path('task_delete/<int:task_id>/', delete_task, name='task_delete'),
    path('task_complete/<int:task_id>', complete_task, name='task_complete'),
    path('my_profile/', ShowProfile.as_view(), name='show_profile'),
]


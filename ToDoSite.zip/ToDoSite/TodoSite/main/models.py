import datetime

from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse


# Create your models here.
class Task(models.Model):
    name = models.CharField(max_length=50, verbose_name='Название задачи')
    content = models.TextField(blank=False, verbose_name='Задача')
    status = models.BooleanField(default=False, verbose_name='Статус')
    time_now = datetime.datetime.now()
    time_create = models.DateTimeField(verbose_name='Время создания', default=time_now)
    time_done = models.DateTimeField(verbose_name="Время выполнения", default=time_now)
    owner = models.ForeignKey('UserTask', on_delete=models.PROTECT, verbose_name='Владелец')

    def get_absolute_url_for_delete(self):
        return reverse('task_delete', kwargs={'task_id': self.pk})

    def get_absolute_url_for_complete(self):
        return reverse('task_complete', kwargs={'task_id': self.pk})

    class Meta:
        verbose_name = 'Задача'
        verbose_name_plural = "Задачи"
        ordering = ['time_create']


class UserTask(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name='Пользователь')
    all_task_count = models.IntegerField(verbose_name='Всего задач', default=0)
    tasks_in_progress = models.IntegerField(verbose_name='Задач в процессе', default=0)
    completed_tasks = models.IntegerField(verbose_name='Задач выполнено', default=0)
    photo = models.ImageField(blank=True, upload_to="photos/%Y/%m/%d/", verbose_name='Фото', default=None)

    def clean(self):
        if self.tasks_in_progress > 50:
            raise ValueError

    class Meta:
        verbose_name_plural = 'Пользователи'
        verbose_name = 'Пользователь'
        ordering = ['id']

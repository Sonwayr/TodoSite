import datetime

from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import LoginView
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import TemplateView, CreateView, ListView
from .models import *
from .utils import *
from .forms import RegisterUserForm, LoginUserForm, CreateTaskForm
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.cache import cache


def main_page(request):
    return render(request, 'main/main.html', {'title': 'Главная страница'})


class RegisterUser(DataMixin, CreateView):
    template_name = 'main/register.html'  # Шаблон для отображения формы регистрации
    form_class = RegisterUserForm  # Форма для регистрации пользователя
    success_url = reverse_lazy('login')  # URL для перенаправления после успешной регистрации

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title='Регистрация')
        return dict(list(context.items()) + list(c_def.items()))

    def form_valid(self, form):
        # При сохранении формы, создаем пользователя и автоматически выполняем вход
        user = form.save()
        UserTask.objects.create(user=user)
        login(self.request, user)
        return redirect('main')


class ShowTasks(LoginRequiredMixin, DataMixin, ListView):
    model = Task
    template_name = 'main/tasks.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title='Мои задачи')
        # Добавляем в контекст queryset tasks_in_progress
        user_task = self.get_user_task()
        context["tasks_completed"] = self.get_progress_tasks(status=1, user_task=user_task, limit=10)
        context["tasks_in_progress"] = self.get_progress_tasks(status=0, user_task=user_task)

        return dict(list(context.items()) + list(c_def.items()))


class ShowProfile(LoginRequiredMixin, DataMixin, ListView):
    model = UserTask
    template_name = 'main/profile.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title='Мой профиль')
        user_task = self.get_user_task()
        completed_tasks = user_task.task_set.filter(status=True).order_by('-time_done')[:5]
        in_progress_tasks = user_task.task_set.filter(status=False).order_by('-time_create')[:5]
        context['user'] = user_task
        context["tasks_completed"] = completed_tasks
        context["tasks_in_progress"] = in_progress_tasks
        return {**context, **c_def}


class CreateTask(LoginRequiredMixin, DataMixin, CreateView):
    template_name = 'main/add_task.html'
    form_class = CreateTaskForm

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['next'] = self.request.META.get('HTTP_REFERER')
        c_def = self.get_user_context(title='Добавление задачи')
        return dict(list(context.items()) + list(c_def.items()))

    def form_valid(self, form):
        user = self.request.user
        user_task = UserTask.objects.get(user=user)
        context = form.cleaned_data
        Task.objects.create(name=context['name'], content=context['content'], owner=user_task)
        user_task.all_task_count += 1
        user_task.tasks_in_progress += 1
        user_task.save()
        next_url = self.request.POST.get('next')
        if next_url:
            return HttpResponseRedirect(next_url)
            # Возврат URL по умолчанию, если параметр next не указан
        return HttpResponseRedirect(reverse('show_tasks'))


class LoginUser(DataMixin, LoginView):
    template_name = 'main/login.html'
    form_class = LoginUserForm

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title='Авторизация')
        return dict(list(context.items()) + list(c_def.items()))

    def get_success_url(self):
        return reverse_lazy('show_tasks')


def logout_user(requset):
    logout(requset)
    return redirect('main')


def delete_task(request, task_id):
    user = request.user
    user_task = UserTask.objects.get(user=user)
    task = get_object_or_404(Task, pk=task_id)

    user_task.all_task_count -= 1
    if not task.status:
        user_task.tasks_in_progress -= 1

    task.delete()
    user_task.save()
    referring_url = request.META.get('HTTP_REFERER')

    # Выполнение редиректа на текущую страницу
    return redirect(referring_url)


def complete_task(request, task_id):
    user = request.user
    user_task = UserTask.objects.get(user=user)
    task = get_object_or_404(Task, pk=task_id)

    user_task.completed_tasks += 1
    user_task.tasks_in_progress -= 1
    task.status = 1
    task.time_done = datetime.datetime.now()

    task.save()
    user_task.save()
    referring_url = request.META.get('HTTP_REFERER')

    # Выполнение редиректа на текущую страницу
    return redirect(referring_url)

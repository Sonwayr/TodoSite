from main.models import *


class DataMixin:
    def get_user_context(self, **kwargs):
        context = kwargs
        return context

    def get_progress_tasks(self, status, user_task, limit=None):
        queryset = self.get_queryset()  # Используем self.get_queryset() вместо super().get_queryset()
        # Фильтруем queryset по полю owner и status для задач в процессе
        if not status:

            in_progress_tasks = queryset.filter(owner=user_task, status=status).order_by('-time_create')
        else:
            in_progress_tasks = queryset.filter(owner=user_task, status=status).order_by('-time_done')[:limit]

        return in_progress_tasks

    def get_user_task(self):
        user = self.request.user
        user_task = UserTask.objects.get(user=user)
        return user_task